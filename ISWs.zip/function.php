<?php
/**
 * User: woop
 */

if(!function_exists('get_costom_tax_types_isw')){
    function get_costom_tax_types_isw(){
        return apply_filters('get_costom_tax_types_isw_', array(
            'colorpicker' => __('Colorpicker', ''),
            'image'       => __('Image', ''),
            'label'       => __('Label', '')
            )
        );
    }
}
if(!function_exists('wp_version_isw')){
	function wp_version_isw(){
		global $wp_version;
		$version = (int)$wp_version;
		return $version;
	}
}

if(!function_exists('get_term_meta_isw')){
	function get_term_meta_isw($termId, $key, $single = true){
		$version = wp_version_isw();
		if($version >= 2.6){
			return function_exists('get_term_meta')? get_term_meta( $term_Id, $key, $single) : get_metadata( 'woocommerce_term', $termId, $key, $single);
		}else{
			return get_woocommerce_term_meta($term_id, $key, $single);
		}
	} 
}
if(!function_exists('update_term_meta_isw')){
	function update_term_meta_isw($term_id, $meta_key, $meta_value, $prev_value = ''){
		$version = wp_version_isw();
		if($version >= 2.6){
			return function_exists('updata_term_meta') ? updata_term_meta( $term_id, $meta_key, $meta_value, $prev_value) : update_metadata( 'woocommerce_term', $term_id, $meta_key, $meta_value, $prev_value);
		} else {
			return update_woocommerce_term_meta( $term_id, $meta_key, $meta_value, $prev_value = '');
		}
	}
}

