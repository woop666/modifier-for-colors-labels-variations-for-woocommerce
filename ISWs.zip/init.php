<?php
/*
Plugin Name: Modifier for YITH WooCommerce Color and Label Variations
Plugin URI: //страница_с_описанием_плагина_и_его_обновлений
Description: Краткое описание плагина.
Version: 1.0
Author: woop
Author URI: //страница_автора_плагина
*/

if(!defined( 'ABSPATH' ) ) { exit;} //exit if not directory

$plugin = 'yith-essential-kit-for-woocommerce/init.php';
require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if(is_plugin_active($plugin)){
    echo "Plugin is included";
}else{
    echo "Plugin is not included";
}



function ind_input_style_woocommerce() {
    global $woocommerce;

    if(! isset($woocommerce)) return;

    load_plugin_textdomain('input-style-woocommerce', false, dirname(plugin_basename( __FILE__)).'/language/');

    require_once('Input_Style_Woocommerce.php');
    require_once('function.php');
    require_once('Input_Style_Woocommerce_admin.php');


    //Start the plugin!
    global $ind_insw;
    $ind_insw = new Input_Style_Woocommerce();

}
//add_action('plugins_loaded', 'ind_input_style_woocommerce');
